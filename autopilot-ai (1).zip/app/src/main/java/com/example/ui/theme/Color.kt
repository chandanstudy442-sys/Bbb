package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDark = Color(0xFF00B4D8)
val NeonViolet = Color(0xFF9D4EDD)
val NeonPurple = Color(0xFF7209B7)
val GlowGreen = Color(0xFF00E676)
val AmberWarning = Color(0xFFFFB703)
val ErrorRed = Color(0xFFFF5252)

val DarkBackground = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF131826)
val DarkSurfaceVariant = Color(0xFF1D2436)
val DarkSurfaceHighlight = Color(0xFF263048)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
