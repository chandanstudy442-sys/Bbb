package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CommandLog
import com.example.data.local.Macro
import com.example.domain.ActionResult
import com.example.ui.MainViewModel
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GlowGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val isOverlayGranted by viewModel.isOverlayGranted.collectAsState()
    val isAccessibilityGranted by viewModel.isAccessibilityGranted.collectAsState()
    val isMicGranted by viewModel.isMicGranted.collectAsState()
    val isFloatingRunning by viewModel.isFloatingAgentRunning.collectAsState()
    val isListening by viewModel.voiceManager.isListening.collectAsState()
    val partialSpeech by viewModel.voiceManager.partialText.collectAsState()
    val soundLevel by viewModel.voiceManager.soundLevel.collectAsState()
    val lastResult by viewModel.lastActionResult.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val logs by viewModel.commandLogs.collectAsState()
    val macros by viewModel.macros.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var textInput by remember { mutableStateOf("") }

    // Launcher for mic runtime permission
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshPermissions()
    }

    LaunchedEffect(Unit) {
        viewModel.refreshPermissions()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(NeonCyan, NeonViolet))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = "AI Agent Icon",
                                tint = DarkBackground,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AI Phone Agent",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isFloatingRunning) "Floating Agent Active on Screen" else "Real Mobile Voice Controller",
                                color = if (isFloatingRunning) GlowGreen else TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshPermissions() },
                        modifier = Modifier.testTag("refresh_permissions_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Permissions",
                            tint = NeonCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Header
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = NeonCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = NeonCyan
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Agent Hub", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Access Setup", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                            val grantedCount = (if (isOverlayGranted) 1 else 0) + (if (isAccessibilityGranted) 1 else 0) + (if (isMicGranted) 1 else 0)
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (grantedCount == 3) GlowGreen else AmberWarning)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "$grantedCount/3",
                                    color = DarkBackground,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("History (${logs.size})", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            when (selectedTab) {
                0 -> AgentHubTab(
                    isFloatingRunning = isFloatingRunning,
                    isOverlayGranted = isOverlayGranted,
                    isAccessibilityGranted = isAccessibilityGranted,
                    isListening = isListening,
                    isProcessing = isProcessing,
                    partialSpeech = partialSpeech,
                    soundLevel = soundLevel,
                    lastResult = lastResult,
                    textInput = textInput,
                    macros = macros,
                    onToggleFloating = { viewModel.toggleFloatingAgent(context) },
                    onMicClick = {
                        if (!isMicGranted) {
                            micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                        } else {
                            if (isListening) viewModel.stopListening() else viewModel.startListening()
                        }
                    },
                    onTextInputChange = { textInput = it },
                    onSubmitCommand = {
                        viewModel.processCommand(it)
                        textInput = ""
                    },
                    onMacroClick = { macro -> viewModel.executeMacro(macro) },
                    onGoToSetup = { selectedTab = 1 }
                )
                1 -> AccessSetupTab(
                    isOverlayGranted = isOverlayGranted,
                    isAccessibilityGranted = isAccessibilityGranted,
                    isMicGranted = isMicGranted,
                    onRequestOverlay = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                        context.startActivity(intent)
                    },
                    onRequestAccessibility = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    },
                    onRequestMic = {
                        micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    }
                )
                2 -> HistoryTab(
                    logs = logs,
                    onClear = { viewModel.clearHistory() },
                    onRetryCommand = { prompt -> viewModel.processCommand(prompt) }
                )
            }
        }
    }
}

@Composable
fun AgentHubTab(
    isFloatingRunning: Boolean,
    isOverlayGranted: Boolean,
    isAccessibilityGranted: Boolean,
    isListening: Boolean,
    isProcessing: Boolean,
    partialSpeech: String,
    soundLevel: Float,
    lastResult: ActionResult?,
    textInput: String,
    macros: List<Macro>,
    onToggleFloating: () -> Unit,
    onMicClick: () -> Unit,
    onTextInputChange: (String) -> Unit,
    onSubmitCommand: (String) -> Unit,
    onMacroClick: (Macro) -> Unit,
    onGoToSetup: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Floating Home Screen Agent Hero Card
        item {
            FloatingHeroCard(
                isFloatingRunning = isFloatingRunning,
                isOverlayGranted = isOverlayGranted,
                onToggle = onToggleFloating,
                onGoToSetup = onGoToSetup
            )
        }

        // 2. Interactive Voice & Command Console
        item {
            VoiceControlCard(
                isListening = isListening,
                isProcessing = isProcessing,
                partialSpeech = partialSpeech,
                soundLevel = soundLevel,
                lastResult = lastResult,
                textInput = textInput,
                onMicClick = onMicClick,
                onTextInputChange = onTextInputChange,
                onSubmitCommand = onSubmitCommand
            )
        }

        // 3. Quick Action Automations Grid
        item {
            Text(
                text = "Quick Mobile Actions (एक क्लिक में कंट्रोल)",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            QuickActionsGrid(
                macros = macros,
                onMacroClick = onMacroClick
            )
        }

        // 4. Hindi Voice Commands Guide Card
        item {
            VoiceCommandsGuideCard()
        }
    }
}

@Composable
fun FloatingHeroCard(
    isFloatingRunning: Boolean,
    isOverlayGranted: Boolean,
    onToggle: () -> Unit,
    onGoToSetup: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(20.dp))
            .border(
                1.5.dp,
                if (isFloatingRunning) GlowGreen else NeonCyan.copy(alpha = 0.5f),
                RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (isFloatingRunning) GlowGreen.copy(alpha = 0.2f)
                                else NeonCyan.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Floating Home Screen",
                            tint = if (isFloatingRunning) GlowGreen else NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Home Screen Floating Agent",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (isFloatingRunning) "Screen par floating bubble active hai" else "Home screen aur sabhi apps par chale",
                            color = if (isFloatingRunning) GlowGreen else TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Switch(
                    checked = isFloatingRunning,
                    onCheckedChange = {
                        if (!isOverlayGranted) {
                            onGoToSetup()
                        } else {
                            onToggle()
                        }
                    },
                    modifier = Modifier.testTag("floating_agent_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = DarkBackground,
                        checkedTrackColor = GlowGreen,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = DarkSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Isko on karne ke bad ek glowing AI orb aapke phone ke home screen par hamesha rahega. Aap kisi bhi app ya WhatsApp me ho, orb ko tap karke turant voice command de sakte hain.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )

            if (!isOverlayGranted) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onGoToSetup,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, AmberWarning),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberWarning)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Overlay Access Chahiye (Click karein)", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun VoiceControlCard(
    isListening: Boolean,
    isProcessing: Boolean,
    partialSpeech: String,
    soundLevel: Float,
    lastResult: ActionResult?,
    textInput: String,
    onMicClick: () -> Unit,
    onTextInputChange: (String) -> Unit,
    onSubmitCommand: (String) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "micPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "micScale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(24.dp))
            .border(1.dp, NeonViolet.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Voice Command Assistant",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = "Tap karke bolein: \"WhatsApp kholo\", \"Torch on karo\", etc.",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Big Glowing Mic Button
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .scale(if (isListening) pulseScale else 1f)
                    .shadow(16.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        if (isListening)
                            Brush.radialGradient(listOf(GlowGreen, NeonCyan))
                        else
                            Brush.linearGradient(listOf(NeonCyan, NeonViolet))
                    )
                    .clickable { onMicClick() }
                    .testTag("main_mic_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Listening Button",
                    tint = DarkBackground,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Status label
            if (isListening) {
                Text(
                    text = "Aapki aawaz sun raha hoon...",
                    color = GlowGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            } else if (isProcessing) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = NeonCyan, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "AI Command process kar raha hai...", color = NeonCyan, fontSize = 13.sp)
                }
            } else {
                Text(
                    text = "Mic par tap karein ya neeche type karein",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            // Real-time voice transcript banner
            if (partialSpeech.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceHighlight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"$partialSpeech\"",
                        color = NeonCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Last Action Executed Banner
            if (lastResult != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (lastResult.isSuccess) GlowGreen.copy(alpha = 0.15f) else AmberWarning.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, if (lastResult.isSuccess) GlowGreen else AmberWarning),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (lastResult.isSuccess) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (lastResult.isSuccess) GlowGreen else AmberWarning,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Action: ${lastResult.actionName}",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = lastResult.message,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Text Input fallback
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = onTextInputChange,
                    placeholder = { Text("Command likhein (e.g. YouTube kholo)", fontSize = 12.sp, color = TextSecondary) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("command_text_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkSurfaceVariant,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = NeonCyan
                    ),
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSubmitCommand(textInput)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .testTag("send_command_button")
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = DarkBackground)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuickActionsGrid(
    macros: List<Macro>,
    onMacroClick: (Macro) -> Unit
) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        macros.forEach { macro ->
            QuickMacroButton(macro = macro, onClick = { onMacroClick(macro) })
        }
    }
}

@Composable
fun QuickMacroButton(
    macro: Macro,
    onClick: () -> Unit
) {
    val icon = when (macro.iconName) {
        "Home" -> Icons.Default.Home
        "FlashlightOn" -> Icons.Default.FlashlightOn
        "Chat" -> Icons.AutoMirrored.Filled.Chat
        "PlayArrow" -> Icons.Default.PlayArrow
        "Apps" -> Icons.Default.Apps
        "ArrowBack" -> Icons.AutoMirrored.Filled.ArrowBack
        "BatteryChargingFull" -> Icons.Default.BatteryChargingFull
        "CameraAlt" -> Icons.Default.CameraAlt
        "ArrowDownward" -> Icons.Default.ArrowDownward
        "Description" -> Icons.Default.Description
        "Language" -> Icons.Default.Language
        else -> Icons.Default.SmartToy
    }

    Surface(
        modifier = Modifier
            .clickable { onClick() }
            .testTag("macro_item_${macro.id}"),
        shape = RoundedCornerShape(14.dp),
        color = DarkSurface,
        border = BorderStroke(1.dp, DarkSurfaceHighlight)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = macro.title,
                tint = NeonCyan,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = macro.title,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = macro.hindiTitle,
                    color = TextSecondary,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun VoiceCommandsGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Voice Commands Examples (Kya bol sakte hain)",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            val examples = listOf(
                "\"Neeche scroll karo\" / \"Scroll down\"" to "Screen khud neeche scroll karega",
                "\"Upar scroll karo\" / \"Scroll up\"" to "Screen upar scroll karega",
                "\"Form bhar do (mera naam Rahul, number...)\"" to "Screen ke form fields me data bhar dega",
                "\"Website nikalo google.com\"" to "Browser me website nikal kar khol dega",
                "\"Submit button dabao\" / \"Submit karo\"" to "Screen par submit/done button click karega",
                "\"Screen par kya likha hai\"" to "Screen content padhkar sunayega",
                "\"Torch on karo\" / \"Torch band karo\"" to "Flashlight chalu ya band karega",
                "\"WhatsApp kholo\"" to "Direct WhatsApp app open karega",
                "\"Home screen par jao\"" to "Device ki main home screen par le jayega",
                "\"YouTube pe song chalao\"" to "Direct search karke play karega",
                "\"Sound badhao\" / \"Awaz kam karo\"" to "Volume adjust karega"
            )

            examples.forEach { (cmd, desc) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = cmd, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text(text = desc, color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AccessSetupTab(
    isOverlayGranted: Boolean,
    isAccessibilityGranted: Boolean,
    isMicGranted: Boolean,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onRequestMic: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Ek Baar Access Setup (One-Time Permissions)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Jaise aapne manga: ek baar permission grant karne ke bad AI agent pure mobile ke home screen aur kisi bhi app me voice se phone control kar sakega.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Permission 1: Draw over other apps (Overlay)
        item {
            PermissionItemCard(
                title = "1. Draw Over Other Apps (Overlay)",
                hindiTitle = "होम स्क्रीन पर फ्लोटिंग AI बबल दिखाने के लिए",
                description = "Is permission se AI agent ka floating bubble aapke phone screen par hamesha rehta hai, chahe aap kisi bhi app me ho.",
                isGranted = isOverlayGranted,
                buttonText = if (isOverlayGranted) "Active (Granted)" else "Enable Overlay Permission",
                onAction = onRequestOverlay,
                testTag = "enable_overlay_btn"
            )
        }

        // Permission 2: Accessibility Service
        item {
            PermissionItemCard(
                title = "2. Accessibility Control Service",
                hindiTitle = "फोन को वास्तव में कंट्रोल करने के लिए (Home, Back, Recents)",
                description = "Yeh service AI agent ko 'Home screen par jao', 'Back button dabao', 'Recent apps kholo', aur 'Notification panel kholo' jaise real system actions karne deti hai.",
                isGranted = isAccessibilityGranted,
                buttonText = if (isAccessibilityGranted) "Active (Connected)" else "Enable Accessibility Service",
                onAction = onRequestAccessibility,
                testTag = "enable_accessibility_btn"
            )
        }

        // Permission 3: Microphone
        item {
            PermissionItemCard(
                title = "3. Microphone Access",
                hindiTitle = "आवाज से कमांड सुनने के लिए",
                description = "Hindi aur English me bol kar mobile ko command dene ke liye mic permission zaroori hai.",
                isGranted = isMicGranted,
                buttonText = if (isMicGranted) "Active (Granted)" else "Allow Microphone",
                onAction = onRequestMic,
                testTag = "enable_mic_btn"
            )
        }
    }
}

@Composable
fun PermissionItemCard(
    title: String,
    hindiTitle: String,
    description: String,
    isGranted: Boolean,
    buttonText: String,
    onAction: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isGranted) GlowGreen.copy(alpha = 0.6f) else AmberWarning.copy(alpha = 0.6f),
                RoundedCornerShape(18.dp)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = hindiTitle, color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isGranted) GlowGreen.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isGranted) "GRANTED" else "REQUIRED",
                        color = if (isGranted) GlowGreen else AmberWarning,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = description, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onAction,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(testTag),
                enabled = !isGranted,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) DarkSurfaceVariant else NeonCyan,
                    disabledContainerColor = DarkSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = if (isGranted) GlowGreen else DarkBackground,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = buttonText,
                    color = if (isGranted) GlowGreen else DarkBackground,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun HistoryTab(
    logs: List<CommandLog>,
    onClear: () -> Unit,
    onRetryCommand: (String) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Command History (${logs.size})",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            if (logs.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear History",
                        tint = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Koi purana command nahi hai.",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Mic se bol kar ya type karke pehla command dein!",
                        color = TextTertiary,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(logs, key = { it.id }) { log ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onRetryCommand(log.prompt) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = log.prompt,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (log.isSuccess) GlowGreen.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = log.actionType,
                                        color = if (log.isSuccess) GlowGreen else AmberWarning,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = log.responseText,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dateFormat.format(Date(log.timestamp)),
                                color = TextTertiary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
