package com.example.ui

import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.PhoneAgentApplication
import com.example.data.local.CommandLog
import com.example.data.local.Macro
import com.example.domain.AIAgentEngine
import com.example.domain.ActionResult
import com.example.domain.DeviceAction
import com.example.domain.DeviceController
import com.example.service.FloatingAgentService
import com.example.service.PhoneAgentAccessibilityService
import com.example.util.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = (application as PhoneAgentApplication).database
    private val deviceController = DeviceController(application)
    private val aiEngine = AIAgentEngine()

    private val _isOverlayGranted = MutableStateFlow(false)
    val isOverlayGranted: StateFlow<Boolean> = _isOverlayGranted.asStateFlow()

    private val _isAccessibilityGranted = MutableStateFlow(false)
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _isMicGranted = MutableStateFlow(false)
    val isMicGranted: StateFlow<Boolean> = _isMicGranted.asStateFlow()

    val isFloatingAgentRunning: StateFlow<Boolean> = FloatingAgentService.isRunning

    private val _lastActionResult = MutableStateFlow<ActionResult?>(null)
    val lastActionResult: StateFlow<ActionResult?> = _lastActionResult.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    val commandLogs: StateFlow<List<CommandLog>> = db.commandLogDao()
        .getAllLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val macros: StateFlow<List<Macro>> = db.macroDao()
        .getAllMacros()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val voiceManager = VoiceManager(application) { voiceText ->
        processCommand(voiceText)
    }

    init {
        refreshPermissions()
    }

    fun refreshPermissions() {
        val context = getApplication<Application>()
        _isOverlayGranted.value = Settings.canDrawOverlays(context)
        _isAccessibilityGranted.value = PhoneAgentAccessibilityService.instance != null
        _isMicGranted.value = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun toggleFloatingAgent(context: Context) {
        if (isFloatingAgentRunning.value) {
            FloatingAgentService.stop(context)
        } else {
            if (Settings.canDrawOverlays(context)) {
                FloatingAgentService.start(context)
            }
        }
    }

    fun startListening() {
        voiceManager.startListening()
    }

    fun stopListening() {
        voiceManager.stopListening()
    }

    fun processCommand(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            _isProcessing.value = true
            val action = aiEngine.interpretCommand(prompt)
            val result = deviceController.executeAction(action)
            _lastActionResult.value = result
            _isProcessing.value = false
            voiceManager.speak(result.spokenFeedback)

            db.commandLogDao().insertLog(
                CommandLog(
                    prompt = prompt,
                    actionType = result.actionName,
                    target = null,
                    isSuccess = result.isSuccess,
                    responseText = result.message
                )
            )
        }
    }

    fun executeMacro(macro: Macro) {
        val action: DeviceAction = when (macro.actionType) {
            "GLOBAL_HOME" -> DeviceAction.NavigateHome
            "GLOBAL_BACK" -> DeviceAction.NavigateBack
            "SHOW_RECENTS" -> DeviceAction.ShowRecents
            "TOGGLE_FLASHLIGHT" -> DeviceAction.ToggleFlashlight(null)
            "CHECK_BATTERY" -> DeviceAction.CheckBattery
            "OPEN_APP" -> DeviceAction.OpenApp(macro.title, macro.payload)
            "SCROLL_DOWN" -> DeviceAction.ScrollScreen(true)
            "SCROLL_UP" -> DeviceAction.ScrollScreen(false)
            "FILL_FORM" -> DeviceAction.FillForm(macro.payload ?: "Auto")
            "OPEN_WEBSITE" -> DeviceAction.OpenWebsite(macro.payload ?: "https://www.google.com")
            "SUBMIT_BUTTON" -> DeviceAction.ClickSubmitButton
            "READ_SCREEN" -> DeviceAction.ReadScreenContent
            else -> DeviceAction.UnknownAction(macro.title)
        }

        viewModelScope.launch {
            val result = deviceController.executeAction(action)
            _lastActionResult.value = result
            voiceManager.speak(result.spokenFeedback)

            db.commandLogDao().insertLog(
                CommandLog(
                    prompt = macro.hindiTitle,
                    actionType = result.actionName,
                    target = macro.payload,
                    isSuccess = result.isSuccess,
                    responseText = result.message
                )
            )
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            db.commandLogDao().clearLogs()
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
