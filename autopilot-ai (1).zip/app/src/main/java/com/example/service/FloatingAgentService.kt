package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.PhoneAgentApplication
import com.example.R
import com.example.data.local.CommandLog
import com.example.domain.AIAgentEngine
import com.example.domain.DeviceAction
import com.example.domain.DeviceController
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GlowGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.ServiceLifecycleOwner
import com.example.util.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FloatingAgentService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var deviceController: DeviceController
    private lateinit var aiEngine: AIAgentEngine
    private lateinit var voiceManager: VoiceManager

    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private val lifecycleOwner = ServiceLifecycleOwner()

    private val _isExpanded = MutableStateFlow(false)
    private val _lastMessage = MutableStateFlow("Tap mic to speak command")

    override fun onCreate() {
        super.onCreate()
        lifecycleOwner.start()

        deviceController = DeviceController(this)
        aiEngine = AIAgentEngine()
        voiceManager = VoiceManager(this) { recognizedText ->
            handleCommand(recognizedText)
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        _isRunning.value = true

        if (Settings.canDrawOverlays(this)) {
            setupFloatingView()
        }
    }

    private fun setupFloatingView() {
        val wm = windowManager ?: return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }
        layoutParams = params

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                val isExpanded by _isExpanded.collectAsState()
                val isListening by voiceManager.isListening.collectAsState()
                val partialSpeech by voiceManager.partialText.collectAsState()
                val soundLevel by voiceManager.soundLevel.collectAsState()
                val lastMsg by _lastMessage.collectAsState()

                FloatingOverlayContent(
                    isExpanded = isExpanded,
                    isListening = isListening,
                    soundLevel = soundLevel,
                    speechText = if (isListening && partialSpeech.isNotBlank()) partialSpeech else lastMsg,
                    onToggleExpand = { startListening ->
                        toggleExpanded(startVoiceImmediately = startListening)
                    },
                    onMicClick = {
                        if (isListening) voiceManager.stopListening() else voiceManager.startListening()
                    },
                    onQuickAction = { action ->
                        executeDirectAction(action)
                    },
                    onSubmitText = { text ->
                        handleCommand(text)
                    },
                    onCloseService = {
                        stopSelf()
                    }
                )
            }
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isMoving = false

        composeView.setOnTouchListener { _, event ->
            if (_isExpanded.value) {
                // When expanded, let Compose handle clicks internally
                return@setOnTouchListener false
            }

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isMoving = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                        isMoving = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        wm.updateViewLayout(composeView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isMoving) {
                        // Immediately expand and start voice listening with one tap!
                        toggleExpanded(startVoiceImmediately = true)
                    }
                    true
                }
                else -> false
            }
        }

        floatingView = composeView
        try {
            wm.addView(composeView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun toggleExpanded(startVoiceImmediately: Boolean = false) {
        val wm = windowManager ?: return
        val view = floatingView ?: return
        val params = layoutParams ?: return

        val newExpanded = !_isExpanded.value
        _isExpanded.value = newExpanded

        if (newExpanded) {
            params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            params.width = WindowManager.LayoutParams.MATCH_PARENT
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            params.x = 0
            params.y = 80
            if (startVoiceImmediately) {
                voiceManager.startListening()
            }
        } else {
            voiceManager.stopListening()
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            params.width = WindowManager.LayoutParams.WRAP_CONTENT
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.TOP or Gravity.START
            params.x = 100
            params.y = 300
        }

        try {
            wm.updateViewLayout(view, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleCommand(prompt: String) {
        if (prompt.isBlank()) return
        serviceScope.launch {
            _lastMessage.value = "Processing: \"$prompt\"..."
            val action = aiEngine.interpretCommand(prompt)
            val result = deviceController.executeAction(action)
            _lastMessage.value = result.message
            voiceManager.speak(result.spokenFeedback)

            // Log to database
            val app = application as? PhoneAgentApplication
            app?.database?.commandLogDao()?.insertLog(
                CommandLog(
                    prompt = prompt,
                    actionType = result.actionName,
                    target = null,
                    isSuccess = result.isSuccess,
                    responseText = result.message
                )
            )
        }
    }

    private fun executeDirectAction(action: DeviceAction) {
        serviceScope.launch {
            val result = deviceController.executeAction(action)
            _lastMessage.value = result.message
            voiceManager.speak(result.spokenFeedback)

            val app = application as? PhoneAgentApplication
            app?.database?.commandLogDao()?.insertLog(
                CommandLog(
                    prompt = "Quick Action: ${result.actionName}",
                    actionType = result.actionName,
                    target = null,
                    isSuccess = result.isSuccess,
                    responseText = result.message
                )
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_desc)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_active_title))
            .setContentText(getString(R.string.overlay_active_desc))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunning.value = false
        lifecycleOwner.stop()
        voiceManager.destroy()

        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        floatingView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "phone_agent_overlay_channel"
        private const val NOTIFICATION_ID = 101

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, FloatingAgentService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingAgentService::class.java)
            context.stopService(intent)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FloatingOverlayContent(
    isExpanded: Boolean,
    isListening: Boolean,
    soundLevel: Float,
    speechText: String,
    onToggleExpand: (startListening: Boolean) -> Unit,
    onMicClick: () -> Unit,
    onQuickAction: (DeviceAction) -> Unit,
    onSubmitText: (String) -> Unit,
    onCloseService: () -> Unit
) {
    if (!isExpanded) {
        // Minimized Floating Glowing AI Orb
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val glowScale by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200),
                repeatMode = RepeatMode.Reverse
            ),
            label = "orbGlow"
        )

        Box(
            modifier = Modifier
                .padding(8.dp)
                .size(64.dp)
                .scale(glowScale)
                .shadow(16.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(NeonCyan, NeonViolet, DarkBackground)
                    )
                )
                .border(2.dp, NeonCyan, CircleShape)
                .clickable { onToggleExpand(true) }, // One tap directly starts voice listening on home screen!
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SmartToy,
                contentDescription = "AI Phone Agent - Tap to Speak",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
    } else {
        // Expanded Glassmorphism Controller Card over Home Screen / other apps
        var inputCommand by remember { mutableStateOf("") }
        val audioScale = if (isListening) (1f + (soundLevel * 0.35f)).coerceIn(1f, 1.4f) else 1f

        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(8.dp)
                .shadow(20.dp, RoundedCornerShape(24.dp))
                .border(1.5.dp, Brush.horizontalGradient(listOf(NeonCyan, NeonViolet)), RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.97f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isListening) GlowGreen else NeonCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isListening) "Listening (Sun raha hoon...)" else "AI Mobile Controller",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Row {
                        IconButton(onClick = { onToggleExpand(false) }, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = "Minimize",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(onClick = onCloseService, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live status / recognized speech text display
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (speechText.isNotBlank()) speechText else "Boliye: \"Form bhar do\", \"Scroll down\", \"Website nikalo\", \"Submit dabao\"",
                            color = if (isListening) NeonCyan else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = if (isListening) FontWeight.Medium else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Animated Voice Mic Button with dynamic sound waves
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .scale(audioScale)
                        .shadow(12.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            if (isListening)
                                Brush.linearGradient(listOf(GlowGreen, NeonCyan))
                            else
                                Brush.linearGradient(listOf(NeonCyan, NeonViolet))
                        )
                        .clickable { onMicClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = DarkBackground,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Text(
                    text = if (isListening) "Sun raha hoon... Sab kaam khud hoga!" else "Tap Mic ya direct bolein",
                    color = if (isListening) GlowGreen else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Autonomous Action Pills
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QuickChip(
                        icon = Icons.Default.ArrowDownward,
                        label = "Scroll Down",
                        onClick = { onQuickAction(DeviceAction.ScrollScreen(true)) }
                    )
                    QuickChip(
                        icon = Icons.Default.ArrowUpward,
                        label = "Scroll Up",
                        onClick = { onQuickAction(DeviceAction.ScrollScreen(false)) }
                    )
                    QuickChip(
                        icon = Icons.Default.Description,
                        label = "Form Bharo",
                        onClick = { onQuickAction(DeviceAction.FillForm("Auto")) }
                    )
                    QuickChip(
                        icon = Icons.Default.Language,
                        label = "Website Kholo",
                        onClick = { onQuickAction(DeviceAction.OpenWebsite("https://www.google.com")) }
                    )
                    QuickChip(
                        icon = Icons.Default.CheckCircle,
                        label = "Submit",
                        onClick = { onQuickAction(DeviceAction.ClickSubmitButton) }
                    )
                    QuickChip(
                        icon = Icons.Default.Home,
                        label = "Home",
                        onClick = { onQuickAction(DeviceAction.NavigateHome) }
                    )
                    QuickChip(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        label = "Back",
                        onClick = { onQuickAction(DeviceAction.NavigateBack) }
                    )
                    QuickChip(
                        icon = Icons.Default.FlashlightOn,
                        label = "Torch",
                        onClick = { onQuickAction(DeviceAction.ToggleFlashlight(null)) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Text Input fallback
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputCommand,
                        onValueChange = { inputCommand = it },
                        placeholder = { Text("Command likhein (e.g. scroll down, form bharo)", fontSize = 11.sp, color = TextSecondary) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkSurfaceVariant,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = NeonCyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (inputCommand.isNotBlank()) {
                                onSubmitText(inputCommand)
                                inputCommand = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = DarkBackground)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 3.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        color = DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = NeonCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}
