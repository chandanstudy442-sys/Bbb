package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PhoneAgentAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceActive.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Accessibility events
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance == this) {
            instance = null
            _isServiceActive.value = false
        }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isServiceActive.value = false
        }
    }

    fun triggerHome(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun triggerBack(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun triggerRecents(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun triggerNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun triggerQuickSettings(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    fun triggerLockScreen(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            false
        }
    }

    // ==========================================
    // Autonomous Screen & UI Automation Engine
    // ==========================================

    /**
     * Autonomous scrolling:
     * 1. Attempts ACTION_SCROLL_FORWARD or ACTION_SCROLL_BACKWARD on scrollable nodes.
     * 2. Also dispatches a realistic swipe gesture across the screen (works in Chrome, WebViews, feeds, lists).
     */
    fun scrollScreen(scrollDown: Boolean): Boolean {
        var actionSuccess = false
        val root = rootInActiveWindow
        if (root != null) {
            val scrollableNodes = mutableListOf<AccessibilityNodeInfo>()
            collectScrollableNodes(root, scrollableNodes)
            for (node in scrollableNodes) {
                val action = if (scrollDown) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (node.performAction(action)) {
                    actionSuccess = true
                    break
                }
            }
        }

        // Also perform smooth gesture scroll for full compatibility
        val gestureSuccess = performScrollGesture(scrollDown)
        return actionSuccess || gestureSuccess
    }

    private fun performScrollGesture(scrollDown: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val dm = resources.displayMetrics
        val width = dm.widthPixels.toFloat()
        val height = dm.heightPixels.toFloat()
        val centerX = width / 2f
        val startY = if (scrollDown) height * 0.72f else height * 0.28f
        val endY = if (scrollDown) height * 0.28f else height * 0.72f

        val path = Path().apply {
            moveTo(centerX, startY)
            lineTo(centerX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 300)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * Find and click a specific button or text item on screen.
     * Searches recursively and handles non-clickable child nodes by climbing to parent or using gesture tap.
     */
    fun findAndClickText(targetText: String, tryScroll: Boolean = true): Boolean {
        val cleanTarget = targetText.trim().lowercase()
        if (cleanTarget.isBlank()) return false

        val root = rootInActiveWindow ?: return false
        val matched = findNodeByTextFuzzy(root, cleanTarget)
        if (matched != null) {
            if (clickNodeOrParent(matched)) {
                return true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val rect = Rect()
                matched.getBoundsInScreen(rect)
                if (rect.centerX() > 0 && rect.centerY() > 0) {
                    return clickAtCoordinates(rect.centerX().toFloat(), rect.centerY().toFloat())
                }
            }
        }

        if (tryScroll) {
            scrollScreen(scrollDown = true)
            try {
                Thread.sleep(350)
            } catch (_: Exception) {}
            val rootAfter = rootInActiveWindow ?: return false
            val matchedAfter = findNodeByTextFuzzy(rootAfter, cleanTarget)
            if (matchedAfter != null) {
                return clickNodeOrParent(matchedAfter)
            }
        }
        return false
    }

    /**
     * Autonomous Form Filling:
     * Inspects active window for editable input boxes, matches them to user instructions,
     * and fills them with appropriate values using ACTION_SET_TEXT.
     */
    fun fillActiveScreenForm(formDetails: String): Pair<Int, String> {
        val root = rootInActiveWindow ?: return Pair(0, "Screen connect nahi ho paya")
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        collectEditableNodes(root, editableNodes)

        if (editableNodes.isEmpty()) {
            return Pair(0, "Is screen par koi form ya input box nahi mila")
        }

        val fieldMap = parseFieldMap(formDetails)
        var filledCount = 0

        if (fieldMap.isNotEmpty()) {
            for (node in editableNodes) {
                val hint = (node.hintText?.toString() ?: "").lowercase()
                val text = (node.text?.toString() ?: "").lowercase()
                val viewId = (node.viewIdResourceName ?: "").lowercase()
                val label = getNearbyLabel(node).lowercase()
                val combined = "$hint $text $viewId $label"

                var matchedValue: String? = null
                for ((key, value) in fieldMap) {
                    if (key.isNotBlank() && combined.contains(key)) {
                        matchedValue = value
                        break
                    }
                }

                // If only 1 field was passed and no specific match found, fill first field
                if (matchedValue == null && fieldMap.size == 1 && filledCount == 0) {
                    matchedValue = fieldMap.values.first()
                }

                if (matchedValue != null) {
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, matchedValue)
                    }
                    if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                        filledCount++
                    }
                }
            }
        } else {
            // General text to insert in first editable field
            val firstNode = editableNodes.firstOrNull()
            if (firstNode != null) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, formDetails)
                }
                if (firstNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                    filledCount = 1
                }
            }
        }

        return Pair(filledCount, "$filledCount fields me details bhar di gayi hain")
    }

    /**
     * Find and click Submit / Search / Next / Proceed / Apply button
     */
    fun clickSubmitOrAction(): Boolean {
        val root = rootInActiveWindow ?: return false
        val keywords = listOf(
            "submit", "jama", "search", "khojo", "next", "aage",
            "apply", "done", "confirm", "send", "bhejo", "login",
            "sign in", "continue", "save", "ok"
        )
        for (kw in keywords) {
            val node = findNodeByTextFuzzy(root, kw)
            if (node != null) {
                if (clickNodeOrParent(node)) return true
            }
        }
        return false
    }

    /**
     * Read visible text on screen
     */
    fun readScreenContent(): String {
        val root = rootInActiveWindow ?: return "Screen content uplabdh nahi hai"
        val lines = mutableListOf<String>()
        collectScreenText(root, lines)
        val text = lines.distinct().take(15).joinToString(". ")
        return if (text.isNotBlank()) text else "Screen par padhne ke liye koi text nahi mila"
    }

    // Helper utilities
    private fun collectScrollableNodes(node: AccessibilityNodeInfo?, outList: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isScrollable) {
            outList.add(node)
        }
        for (i in 0 until node.childCount) {
            collectScrollableNodes(node.getChild(i), outList)
        }
    }

    private fun collectEditableNodes(node: AccessibilityNodeInfo?, outList: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        if (node.isEditable) {
            outList.add(node)
        }
        for (i in 0 until node.childCount) {
            collectEditableNodes(node.getChild(i), outList)
        }
    }

    private fun findNodeByTextFuzzy(node: AccessibilityNodeInfo?, target: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        if (text.contains(target) || desc.contains(target)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val result = findNodeByTextFuzzy(node.getChild(i), target)
            if (result != null) return result
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun clickAtCoordinates(x: Float, y: Float): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    private fun getNearbyLabel(node: AccessibilityNodeInfo): String {
        val parent = node.parent ?: return ""
        for (i in 0 until parent.childCount) {
            val child = parent.getChild(i)
            if (child != null && child != node && !child.isEditable && child.text != null) {
                return child.text.toString()
            }
        }
        return ""
    }

    private fun collectScreenText(node: AccessibilityNodeInfo?, outList: MutableList<String>) {
        if (node == null) return
        val text = node.text?.toString()?.trim()
        if (!text.isNullOrBlank() && text.length > 2) {
            outList.add(text)
        }
        for (i in 0 until node.childCount) {
            collectScreenText(node.getChild(i), outList)
        }
    }

    private fun parseFieldMap(text: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val lower = text.lowercase()

        // Name
        val nameRegex = Regex("(?i)(?:naam|name)(?:\\s+hai|\\s+is|\\s*:)?\\s+([a-zA-Z\\u0900-\\u097F]+)")
        nameRegex.find(text)?.let {
            map["name"] = it.groupValues[1]
            map["naam"] = it.groupValues[1]
        }

        // Phone / Mobile
        val phoneRegex = Regex("(?i)(?:mobile|phone|number)(?:\\s+hai|\\s+is|\\s*:)?\\s+([0-9]{10})")
        phoneRegex.find(text)?.let {
            map["phone"] = it.groupValues[1]
            map["mobile"] = it.groupValues[1]
            map["number"] = it.groupValues[1]
        } ?: run {
            // Raw 10 digits
            Regex("[0-9]{10}").find(text)?.let {
                map["phone"] = it.value
                map["mobile"] = it.value
            }
        }

        // Email
        val emailRegex = Regex("([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})")
        emailRegex.find(text)?.let {
            map["email"] = it.value
            map["mail"] = it.value
        }

        return map
    }

    companion object {
        var instance: PhoneAgentAccessibilityService? = null
            private set

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()
    }
}
