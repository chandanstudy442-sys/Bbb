package com.example.domain

class AIAgentEngine(
    private val geminiService: GeminiAgentService = GeminiAgentService()
) {

    suspend fun interpretCommand(prompt: String): DeviceAction {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase()

        // 1. Fast Hindi / English Device Control Matcher
        val fastAction = matchLocalIntent(lower, trimmed)
        if (fastAction != null) {
            return fastAction
        }

        // 2. Advanced Gemini Cloud AI reasoning
        return geminiService.processWithGemini(trimmed)
    }

    private fun matchLocalIntent(lower: String, original: String): DeviceAction? {
        // Autonomous Screen Scrolling
        if (lower.contains("scroll") || lower.contains("neeche karo") || lower.contains("upar karo") || lower.contains("niche karo")) {
            if (lower.contains("dhundho") || lower.contains("nikalo") || lower.contains("find") || lower.contains("search")) {
                val target = extractSearchQuery(original, listOf("scroll karke dhundho", "scroll karke nikalo", "scroll karke", "dhundho", "nikalo", "find"))
                if (target.isNotBlank()) {
                    return DeviceAction.AutoSearchAndClick(target)
                }
            }

            if (lower.contains("upar") || lower.contains("up") || lower.contains("top") || lower.contains("piche")) {
                return DeviceAction.ScrollScreen(scrollDown = false)
            }
            return DeviceAction.ScrollScreen(scrollDown = true)
        }

        // Autonomous Form Filling
        if (lower.contains("form") || lower.contains("fill") || lower.contains("input") || (lower.contains("naam") && lower.contains("bhar"))) {
            if (lower.contains("bharo") || lower.contains("bhar do") || lower.contains("fill") || lower.contains("bana do") || lower.contains("daal do")) {
                val formDetails = extractSearchQuery(original, listOf("form bharo", "form bhar do", "form fill karo", "form me daal do", "form bana do", "form me"))
                val detailsToUse = if (formDetails.isNotBlank()) formDetails else original
                return DeviceAction.FillForm(detailsToUse)
            }
        }

        // Autonomous Website Opening
        if (lower.contains("website") || lower.contains("site") || lower.contains(".com") || lower.contains(".in") || lower.contains(".org") || lower.contains(".gov")) {
            if (lower.contains("kholo") || lower.contains("nikalo") || lower.contains("open") || lower.contains("bana") || lower.contains("jao")) {
                val target = extractSearchQuery(original, listOf("website nikalo", "website kholo", "website open karo", "site kholo", "website", "site"))
                if (target.isNotBlank()) {
                    return DeviceAction.OpenWebsite(target)
                }
            }
        }

        // Click on Screen Elements / Buttons
        if (lower.contains("click") || lower.contains("dabao") || lower.contains("touch")) {
            if (lower.contains("submit") || lower.contains("done") || lower.contains("jama")) {
                return DeviceAction.ClickSubmitButton
            }
            val target = extractSearchQuery(original, listOf("click on", "click karo", "par click karo", "click", "dabao", "button dabao", "button"))
            if (target.isNotBlank()) {
                return DeviceAction.ClickScreenText(target)
            }
        }

        // Submit Button direct
        if (lower == "submit" || lower == "submit karo" || lower.contains("submit button") || lower == "jama karo") {
            return DeviceAction.ClickSubmitButton
        }

        // Read Screen
        if (lower.contains("screen padho") || lower.contains("read screen") || lower.contains("screen read") || lower.contains("kya likha hai")) {
            return DeviceAction.ReadScreenContent
        }

        // Flashlight / Torch
        if (lower.contains("torch") || lower.contains("flashlight") || lower.contains("batti") || lower.contains("light")) {
            return when {
                lower.contains("on") || lower.contains("chalu") || lower.contains("jalao") || lower.contains("start") ->
                    DeviceAction.ToggleFlashlight(true)
                lower.contains("off") || lower.contains("band") || lower.contains("bujhao") || lower.contains("stop") ->
                    DeviceAction.ToggleFlashlight(false)
                else -> DeviceAction.ToggleFlashlight(null)
            }
        }

        // Home Navigation
        if (lower.contains("home") || lower.contains("main screen") || lower.contains("ghar jao") || lower.contains("home screen")) {
            return DeviceAction.NavigateHome
        }

        // Back Navigation
        if (lower.contains("back") || lower.contains("peeche") || lower.contains("piche") || lower.contains("wapas")) {
            return DeviceAction.NavigateBack
        }

        // Recent Apps
        if (lower.contains("recent") || lower.contains("recents") || lower.contains("all apps") || lower.contains("background apps")) {
            return DeviceAction.ShowRecents
        }

        // Notification panel
        if (lower.contains("notification") || lower.contains("notif")) {
            return DeviceAction.OpenNotifications
        }

        // Quick settings
        if (lower.contains("quick setting") || lower.contains("control center")) {
            return DeviceAction.OpenQuickSettings
        }

        // Battery
        if (lower.contains("battery") || lower.contains("charge") || lower.contains("charging")) {
            return DeviceAction.CheckBattery
        }

        // Volume
        if (lower.contains("volume") || lower.contains("sound") || lower.contains("awaz") || lower.contains("awaaz")) {
            return if (lower.contains("kam") || lower.contains("down") || lower.contains("ghatao") || lower.contains("low")) {
                DeviceAction.AdjustVolume(increase = false)
            } else {
                DeviceAction.AdjustVolume(increase = true)
            }
        }

        // Lock screen
        if (lower.contains("lock") || lower.contains("screen band")) {
            return DeviceAction.LockScreen
        }

        // Settings
        if (lower == "settings" || lower.contains("phone settings") || lower.contains("setting kholo")) {
            return DeviceAction.OpenSettings
        }

        // Camera
        if (lower.contains("camera") || lower.contains("photo") || lower.contains("selfie")) {
            return DeviceAction.OpenApp("Camera", null)
        }

        // WhatsApp
        if (lower.contains("whatsapp") || lower.contains("whats app")) {
            return DeviceAction.OpenApp("WhatsApp", "com.whatsapp")
        }

        // YouTube
        if (lower.contains("youtube") || lower.contains("you tube")) {
            val query = extractSearchQuery(original, listOf("youtube pe", "youtube par", "youtube search", "youtube"))
            return if (query.isNotBlank() && (lower.contains("search") || lower.contains("chalao") || lower.contains("play") || lower.contains("song") || lower.contains("gaane"))) {
                DeviceAction.SearchQuery(query, isYoutube = true)
            } else {
                DeviceAction.OpenApp("YouTube", "com.google.android.youtube")
            }
        }

        // Google / Web Search
        if (lower.startsWith("search") || lower.startsWith("google") || lower.contains("khojo")) {
            val query = extractSearchQuery(original, listOf("search", "google", "khojo"))
            if (query.isNotBlank()) {
                return DeviceAction.SearchQuery(query, isYoutube = false)
            }
        }

        // Phone call / dial
        if (lower.contains("call") || lower.contains("dial") || lower.contains("phone lagao")) {
            val target = extractSearchQuery(original, listOf("call", "dial", "phone lagao", "ko"))
            return DeviceAction.CallPhone(target)
        }

        // Chrome
        if (lower.contains("chrome") || lower.contains("browser") || lower.contains("internet")) {
            return DeviceAction.OpenApp("Chrome", "com.android.chrome")
        }

        // Maps
        if (lower.contains("map") || lower.contains("maps") || lower.contains("location") || lower.contains("rasta")) {
            return DeviceAction.OpenApp("Google Maps", "com.google.android.apps.maps")
        }

        // Calculator
        if (lower.contains("calculator") || lower.contains("calc") || lower.contains("hisab")) {
            return DeviceAction.OpenApp("Calculator", "com.google.android.calculator")
        }

        // Clock / Alarm
        if (lower.contains("alarm") || lower.contains("clock") || lower.contains("ghadi")) {
            return DeviceAction.OpenApp("Clock", "com.google.android.deskclock")
        }

        return null
    }

    private fun extractSearchQuery(original: String, prefixes: List<String>): String {
        var result = original
        for (prefix in prefixes) {
            val idx = result.indexOf(prefix, ignoreCase = true)
            if (idx != -1) {
                result = result.substring(idx + prefix.length)
            }
        }
        return result.replace(Regex("(?i)(pe|par|karo|chalao|lagao|kholo|dikhaye|search)"), "").trim()
    }
}
