package com.example.domain

sealed class DeviceAction {
    data class OpenApp(val appName: String, val packageName: String?) : DeviceAction()
    data class ToggleFlashlight(val turnOn: Boolean?) : DeviceAction()
    object NavigateHome : DeviceAction()
    object NavigateBack : DeviceAction()
    object ShowRecents : DeviceAction()
    object OpenNotifications : DeviceAction()
    object OpenQuickSettings : DeviceAction()
    object CheckBattery : DeviceAction()
    data class AdjustVolume(val increase: Boolean) : DeviceAction()
    data class CallPhone(val query: String) : DeviceAction()
    data class SearchQuery(val query: String, val isYoutube: Boolean) : DeviceAction()
    object OpenSettings : DeviceAction()
    object LockScreen : DeviceAction()

    // Autonomous Screen, Form & Web Automation
    data class ScrollScreen(val scrollDown: Boolean) : DeviceAction()
    data class ClickScreenText(val targetText: String) : DeviceAction()
    data class AutoSearchAndClick(val targetText: String) : DeviceAction()
    data class FillForm(val details: String) : DeviceAction()
    data class OpenWebsite(val urlOrQuery: String) : DeviceAction()
    object ClickSubmitButton : DeviceAction()
    object ReadScreenContent : DeviceAction()

    data class AnswerQuestion(val answer: String) : DeviceAction()
    data class UnknownAction(val userMessage: String) : DeviceAction()
}

data class ActionResult(
    val actionName: String,
    val isSuccess: Boolean,
    val message: String,
    val spokenFeedback: String
)
