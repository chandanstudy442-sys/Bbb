package com.example.domain

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiAgentService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun processWithGemini(prompt: String): DeviceAction = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext DeviceAction.AnswerQuestion("AI Engine ready! Configure Gemini API key for advanced reasoning, or use voice commands directly.")
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val systemPrompt = """
            You are an Android Mobile Control AI Agent. The user will give a voice or text command in Hindi, Hinglish, or English.
            Classify the command into one of these strict action formats in JSON:
            
            1. Open App:
            {"action": "OPEN_APP", "appName": "App Name", "packageName": "package or null"}
            
            2. Flashlight / Torch:
            {"action": "FLASHLIGHT", "state": "ON" | "OFF" | "TOGGLE"}
            
            3. Navigation:
            {"action": "NAVIGATE_HOME"}
            {"action": "NAVIGATE_BACK"}
            {"action": "SHOW_RECENTS"}
            {"action": "OPEN_NOTIFICATIONS"}
            {"action": "OPEN_SETTINGS"}
            {"action": "LOCK_SCREEN"}
            
            4. Autonomous Screen & Form Automation:
            {"action": "SCROLL", "direction": "DOWN" | "UP"}
            {"action": "CLICK_TEXT", "target": "Text or button label on screen"}
            {"action": "AUTO_SEARCH_CLICK", "target": "item to search by scrolling and click"}
            {"action": "FILL_FORM", "details": "form input details e.g. Name Rahul, Phone 9876543210"}
            {"action": "OPEN_WEBSITE", "urlOrQuery": "website url or search name"}
            {"action": "SUBMIT_BUTTON"}
            {"action": "READ_SCREEN"}
            
            5. Battery:
            {"action": "CHECK_BATTERY"}
            
            6. Volume:
            {"action": "ADJUST_VOLUME", "direction": "UP" | "DOWN"}
            
            7. Phone Call / Dial:
            {"action": "CALL_PHONE", "target": "number or contact name"}
            
            8. Search:
            {"action": "SEARCH", "query": "search terms", "platform": "YOUTUBE" | "GOOGLE"}
            
            9. General Question or Chat:
            {"action": "ANSWER", "reply": "short helpful response in the user's language (Hindi or English)"}
            
            Output ONLY valid JSON. No markdown ticks, no commentary.
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "User Command: $prompt")
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemPrompt)
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.1)
                put("responseMimeType", "application/json")
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return@withContext DeviceAction.UnknownAction(prompt)

            val rootJson = JSONObject(responseBody)
            val candidates = rootJson.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text")?.trim()

            if (text.isNullOrEmpty()) {
                return@withContext DeviceAction.UnknownAction(prompt)
            }

            parseGeminiJsonToAction(text, prompt)
        } catch (e: Exception) {
            DeviceAction.UnknownAction(prompt)
        }
    }

    private fun parseGeminiJsonToAction(jsonStr: String, fallbackPrompt: String): DeviceAction {
        return try {
            val cleanJson = jsonStr.replace("```json", "").replace("```", "").trim()
            val obj = JSONObject(cleanJson)
            when (obj.optString("action").uppercase()) {
                "OPEN_APP" -> DeviceAction.OpenApp(
                    appName = obj.optString("appName", "App"),
                    packageName = if (obj.has("packageName") && !obj.isNull("packageName")) obj.getString("packageName") else null
                )
                "FLASHLIGHT" -> {
                    val state = obj.optString("state").uppercase()
                    DeviceAction.ToggleFlashlight(
                        when (state) {
                            "ON" -> true
                            "OFF" -> false
                            else -> null
                        }
                    )
                }
                "NAVIGATE_HOME" -> DeviceAction.NavigateHome
                "NAVIGATE_BACK" -> DeviceAction.NavigateBack
                "SHOW_RECENTS" -> DeviceAction.ShowRecents
                "OPEN_NOTIFICATIONS" -> DeviceAction.OpenNotifications
                "OPEN_SETTINGS" -> DeviceAction.OpenSettings
                "LOCK_SCREEN" -> DeviceAction.LockScreen
                "SCROLL" -> {
                    val dir = obj.optString("direction").uppercase()
                    DeviceAction.ScrollScreen(dir != "UP")
                }
                "CLICK_TEXT" -> DeviceAction.ClickScreenText(obj.optString("target", ""))
                "AUTO_SEARCH_CLICK" -> DeviceAction.AutoSearchAndClick(obj.optString("target", ""))
                "FILL_FORM" -> DeviceAction.FillForm(obj.optString("details", fallbackPrompt))
                "OPEN_WEBSITE" -> DeviceAction.OpenWebsite(obj.optString("urlOrQuery", fallbackPrompt))
                "SUBMIT_BUTTON" -> DeviceAction.ClickSubmitButton
                "READ_SCREEN" -> DeviceAction.ReadScreenContent
                "CHECK_BATTERY" -> DeviceAction.CheckBattery
                "ADJUST_VOLUME" -> {
                    val dir = obj.optString("direction").uppercase()
                    DeviceAction.AdjustVolume(dir == "UP")
                }
                "CALL_PHONE" -> DeviceAction.CallPhone(obj.optString("target", ""))
                "SEARCH" -> {
                    val platform = obj.optString("platform").uppercase()
                    DeviceAction.SearchQuery(obj.optString("query", fallbackPrompt), platform == "YOUTUBE")
                }
                "ANSWER" -> DeviceAction.AnswerQuestion(obj.optString("reply", "Haan ji, boliye."))
                else -> DeviceAction.UnknownAction(fallbackPrompt)
            }
        } catch (e: Exception) {
            DeviceAction.UnknownAction(fallbackPrompt)
        }
    }
}
