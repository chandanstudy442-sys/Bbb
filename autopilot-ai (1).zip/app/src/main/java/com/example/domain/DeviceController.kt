package com.example.domain

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import com.example.service.PhoneAgentAccessibilityService

class DeviceController(private val context: Context) {

    private val cameraManager by lazy {
        context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    }
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    private var isTorchOn: Boolean = false

    fun executeAction(action: DeviceAction): ActionResult {
        return when (action) {
            is DeviceAction.OpenApp -> openApp(action.appName, action.packageName)
            is DeviceAction.ToggleFlashlight -> toggleFlashlight(action.turnOn)
            is DeviceAction.NavigateHome -> goHome()
            is DeviceAction.NavigateBack -> goBack()
            is DeviceAction.ShowRecents -> showRecents()
            is DeviceAction.OpenNotifications -> openNotifications()
            is DeviceAction.OpenQuickSettings -> openQuickSettings()
            is DeviceAction.CheckBattery -> checkBattery()
            is DeviceAction.AdjustVolume -> adjustVolume(action.increase)
            is DeviceAction.CallPhone -> dialNumberOrContact(action.query)
            is DeviceAction.SearchQuery -> executeSearch(action.query, action.isYoutube)
            is DeviceAction.OpenSettings -> openSettings()
            is DeviceAction.LockScreen -> lockScreen()
            is DeviceAction.ScrollScreen -> scrollScreen(action.scrollDown)
            is DeviceAction.ClickScreenText -> clickScreenText(action.targetText)
            is DeviceAction.AutoSearchAndClick -> autoSearchAndClick(action.targetText)
            is DeviceAction.FillForm -> fillForm(action.details)
            is DeviceAction.OpenWebsite -> openWebsite(action.urlOrQuery)
            is DeviceAction.ClickSubmitButton -> clickSubmitButton()
            is DeviceAction.ReadScreenContent -> readScreenContent()
            is DeviceAction.AnswerQuestion -> ActionResult(
                actionName = "AI Answer",
                isSuccess = true,
                message = action.answer,
                spokenFeedback = action.answer
            )
            is DeviceAction.UnknownAction -> ActionResult(
                actionName = "Unknown",
                isSuccess = false,
                message = "Command not recognized: ${action.userMessage}",
                spokenFeedback = "Maaf kijiye, main yeh command samajh nahi paya. Kripya dobara bolein."
            )
        }
    }

    private fun openApp(appName: String, packageName: String?): ActionResult {
        val pm = context.packageManager
        val normalized = appName.lowercase().trim()

        // Direct package mapping
        val pkg = packageName ?: when {
            normalized.contains("whatsapp") -> "com.whatsapp"
            normalized.contains("youtube") -> "com.google.android.youtube"
            normalized.contains("chrome") || normalized.contains("browser") -> "com.android.chrome"
            normalized.contains("map") -> "com.google.android.apps.maps"
            normalized.contains("gmail") || normalized.contains("mail") -> "com.google.android.gm"
            normalized.contains("calculator") || normalized.contains("hisab") -> "com.google.android.calculator"
            normalized.contains("clock") || normalized.contains("alarm") -> "com.google.android.deskclock"
            normalized.contains("dialer") || normalized.contains("phone") || normalized.contains("call") -> "com.google.android.dialer"
            else -> null
        }

        // Try launching by package
        if (pkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionResult(
                    actionName = "Open App",
                    isSuccess = true,
                    message = "$appName open ho raha hai",
                    spokenFeedback = "$appName khol raha hoon"
                )
            }
        }

        // Special system intents
        if (normalized.contains("camera") || normalized.contains("photo")) {
            val cameraIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (cameraIntent.resolveActivity(pm) != null) {
                context.startActivity(cameraIntent)
                return ActionResult(
                    actionName = "Open Camera",
                    isSuccess = true,
                    message = "Camera open ho raha hai",
                    spokenFeedback = "Camera khol raha hoon"
                )
            }
        }

        if (normalized.contains("setting")) {
            return openSettings()
        }

        if (normalized.contains("alarm") || normalized.contains("clock")) {
            val alarmIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (alarmIntent.resolveActivity(pm) != null) {
                context.startActivity(alarmIntent)
                return ActionResult(
                    actionName = "Open Alarm",
                    isSuccess = true,
                    message = "Alarms khol diya gaya hai",
                    spokenFeedback = "Alarm khol raha hoon"
                )
            }
        }

        // Fallback: search on Play Store or Web
        return ActionResult(
            actionName = "App Not Found",
            isSuccess = false,
            message = "$appName mobile mein nahi mila.",
            spokenFeedback = "$appName aapke phone mein install nahi lag raha hai."
        )
    }

    private fun toggleFlashlight(turnOn: Boolean?): ActionResult {
        val cm = cameraManager ?: return ActionResult(
            actionName = "Flashlight",
            isSuccess = false,
            message = "Camera manager uplabdh nahi hai",
            spokenFeedback = "Torch support nahi kar raha hai."
        )

        try {
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                val chars = cm.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }

            if (cameraId == null) {
                return ActionResult(
                    actionName = "Flashlight",
                    isSuccess = false,
                    message = "Flashlight hardware nahi mila",
                    spokenFeedback = "Flashlight nahi mili."
                )
            }

            val targetState = turnOn ?: !isTorchOn
            cm.setTorchMode(cameraId, targetState)
            isTorchOn = targetState

            val stateText = if (targetState) "chalu (ON)" else "band (OFF)"
            val spoken = if (targetState) "Torch chalu kar diya hai." else "Torch band kar diya hai."

            return ActionResult(
                actionName = "Flashlight",
                isSuccess = true,
                message = "Torch $stateText kar diya gaya.",
                spokenFeedback = spoken
            )
        } catch (e: CameraAccessException) {
            return ActionResult(
                actionName = "Flashlight",
                isSuccess = false,
                message = "Torch error: ${e.localizedMessage}",
                spokenFeedback = "Torch on karne mein samasya aayi."
            )
        }
    }

    private fun goHome(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        if (accessibilityService != null) {
            accessibilityService.triggerHome()
            return ActionResult(
                actionName = "Go Home",
                isSuccess = true,
                message = "Home screen par navigate kiya gaya (Accessibility)",
                spokenFeedback = "Home screen par aa gaye hain."
            )
        }

        // Fallback standard home intent
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(homeIntent)
        return ActionResult(
            actionName = "Go Home",
            isSuccess = true,
            message = "Home screen par navigate kiya gaya",
            spokenFeedback = "Home screen khol di gayi hai."
        )
    }

    private fun goBack(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        return if (accessibilityService != null && accessibilityService.triggerBack()) {
            ActionResult(
                actionName = "Go Back",
                isSuccess = true,
                message = "Back action execute kiya gaya",
                spokenFeedback = "Peeche chale gaye."
            )
        } else {
            ActionResult(
                actionName = "Go Back",
                isSuccess = false,
                message = "Accessibility service required for Global Back",
                spokenFeedback = "Peeche jane ke liye Accessibility permission chahiye."
            )
        }
    }

    private fun showRecents(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        return if (accessibilityService != null && accessibilityService.triggerRecents()) {
            ActionResult(
                actionName = "Recent Apps",
                isSuccess = true,
                message = "Recent apps khola gaya",
                spokenFeedback = "Recent apps dikha raha hoon."
            )
        } else {
            ActionResult(
                actionName = "Recent Apps",
                isSuccess = false,
                message = "Accessibility service required for Recents",
                spokenFeedback = "Recent apps ke liye Accessibility permission enable karein."
            )
        }
    }

    private fun openNotifications(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        return if (accessibilityService != null && accessibilityService.triggerNotifications()) {
            ActionResult(
                actionName = "Notifications",
                isSuccess = true,
                message = "Notification panel khola gaya",
                spokenFeedback = "Notification shade open kar diya hai."
            )
        } else {
            ActionResult(
                actionName = "Notifications",
                isSuccess = false,
                message = "Accessibility permission chahiye",
                spokenFeedback = "Notification panel ke liye Accessibility enable karein."
            )
        }
    }

    private fun openQuickSettings(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        return if (accessibilityService != null && accessibilityService.triggerQuickSettings()) {
            ActionResult(
                actionName = "Quick Settings",
                isSuccess = true,
                message = "Quick settings panel open kiya gaya",
                spokenFeedback = "Quick settings khol diya gaya hai."
            )
        } else {
            ActionResult(
                actionName = "Quick Settings",
                isSuccess = false,
                message = "Accessibility permission chahiye",
                spokenFeedback = "Quick settings ke liye accessibility enable karein."
            )
        }
    }

    private fun checkBattery(): ActionResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) == BatteryManager.BATTERY_STATUS_CHARGING
        } else false

        val chargingText = if (isCharging) " (Charging chal rahi hai)" else ""
        val response = "Phone ki battery $level%$chargingText hai."

        return ActionResult(
            actionName = "Check Battery",
            isSuccess = true,
            message = response,
            spokenFeedback = "Aapki battery $level percent hai."
        )
    }

    private fun adjustVolume(increase: Boolean): ActionResult {
        val am = audioManager ?: return ActionResult(
            actionName = "Volume",
            isSuccess = false,
            message = "Audio manager uplabdh nahi hai",
            spokenFeedback = "Sound control nahi ho paya."
        )

        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)

        val text = if (increase) "Volume badha diya hai" else "Volume kam kar diya hai"
        return ActionResult(
            actionName = "Adjust Volume",
            isSuccess = true,
            message = text,
            spokenFeedback = text
        )
    }

    private fun dialNumberOrContact(query: String): ActionResult {
        val cleanNumber = query.filter { it.isDigit() || it == '+' }
        val intent = if (cleanNumber.isNotEmpty()) {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber"))
        } else {
            Intent(Intent.ACTION_DIAL)
        }.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)

        return ActionResult(
            actionName = "Dialer",
            isSuccess = true,
            message = "Dialer open kiya gaya: $query",
            spokenFeedback = "Dialer khol raha hoon."
        )
    }

    private fun executeSearch(query: String, isYoutube: Boolean): ActionResult {
        val cleanQuery = query.trim()
        val intent = if (isYoutube) {
            val encoded = Uri.encode(cleanQuery)
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded"))
        } else {
            val encoded = Uri.encode(cleanQuery)
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded"))
        }.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)

        val targetPlatform = if (isYoutube) "YouTube" else "Google Search"
        return ActionResult(
            actionName = targetPlatform,
            isSuccess = true,
            message = "$targetPlatform par khoja gaya: $cleanQuery",
            spokenFeedback = "$targetPlatform par search kar raha hoon."
        )
    }

    private fun openSettings(): ActionResult {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        return ActionResult(
            actionName = "Settings",
            isSuccess = true,
            message = "Phone settings khol diya gaya",
            spokenFeedback = "Settings open kar raha hoon."
        )
    }

    private fun lockScreen(): ActionResult {
        val accessibilityService = PhoneAgentAccessibilityService.instance
        return if (accessibilityService != null && accessibilityService.triggerLockScreen()) {
            ActionResult(
                actionName = "Lock Screen",
                isSuccess = true,
                message = "Phone lock kar diya gaya",
                spokenFeedback = "Phone lock ho gaya."
            )
        } else {
            ActionResult(
                actionName = "Lock Screen",
                isSuccess = false,
                message = "Accessibility service required to lock screen",
                spokenFeedback = "Phone lock karne ke liye Accessibility permission chahiye."
            )
        }
    }

    private fun scrollScreen(scrollDown: Boolean): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Scroll",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Scroll karne ke liye Accessibility service on karein."
            )
        }

        val success = service.scrollScreen(scrollDown)
        val direction = if (scrollDown) "Neeche" else "Upar"
        return ActionResult(
            actionName = "Scroll $direction",
            isSuccess = success,
            message = if (success) "Screen $direction scroll ki gayi" else "Screen scroll nahi ho payi",
            spokenFeedback = if (success) "$direction scroll kar diya gaya hai." else "Scroll karne me samasya aayi."
        )
    }

    private fun clickScreenText(targetText: String): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Click Element",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Click karne ke liye Accessibility service on karein."
            )
        }

        val success = service.findAndClickText(targetText, tryScroll = true)
        return ActionResult(
            actionName = "Click '$targetText'",
            isSuccess = success,
            message = if (success) "'$targetText' par click kar diya gaya" else "Screen par '$targetText' nahi mila",
            spokenFeedback = if (success) "$targetText par click kar diya." else "$targetText screen par nahi mila."
        )
    }

    private fun autoSearchAndClick(targetText: String): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Search & Scroll",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Dhundhne ke liye Accessibility service chalu karein."
            )
        }

        val success = service.findAndClickText(targetText, tryScroll = true)
        return ActionResult(
            actionName = "Auto Search",
            isSuccess = success,
            message = if (success) "Scroll karke '$targetText' dhundha aur click kiya" else "'$targetText' page par nahi mila",
            spokenFeedback = if (success) "Scroll karke $targetText nikal kar click kar diya." else "$targetText nahi mila."
        )
    }

    private fun fillForm(details: String): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Fill Form",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Form bharne ke liye Accessibility service on karein."
            )
        }

        val (count, message) = service.fillActiveScreenForm(details)
        return if (count > 0) {
            ActionResult(
                actionName = "Fill Form",
                isSuccess = true,
                message = message,
                spokenFeedback = "Form me $count fields khud bhar diye gaye hain."
            )
        } else {
            ActionResult(
                actionName = "Fill Form",
                isSuccess = false,
                message = message,
                spokenFeedback = "Screen par koi form ya input box nahi mila. Kripya pehle form open karein."
            )
        }
    }

    private fun openWebsite(urlOrQuery: String): ActionResult {
        val clean = urlOrQuery.trim()
        val url = if (clean.startsWith("http://") || clean.startsWith("https://")) {
            clean
        } else if (clean.contains(".com") || clean.contains(".in") || clean.contains(".org") || clean.contains(".net") || clean.contains(".gov") || clean.contains(".edu")) {
            "https://$clean"
        } else {
            "https://www.google.com/search?q=" + Uri.encode(clean)
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        // Try Chrome first
        intent.setPackage("com.android.chrome")
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            intent.setPackage(null)
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                return ActionResult(
                    actionName = "Open Website",
                    isSuccess = false,
                    message = "Browser open nahi ho paya: ${e.message}",
                    spokenFeedback = "Website open karne me samasya aayi."
                )
            }
        }

        return ActionResult(
            actionName = "Open Website",
            isSuccess = true,
            message = "Website khol di gayi hai: $url",
            spokenFeedback = "Website nikal kar khol raha hoon."
        )
    }

    private fun clickSubmitButton(): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Submit",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Accessibility service chalu karein."
            )
        }

        val success = service.clickSubmitOrAction()
        return ActionResult(
            actionName = "Submit / Action",
            isSuccess = success,
            message = if (success) "Submit / Done button click kar diya gaya" else "Submit button nahi mila",
            spokenFeedback = if (success) "Submit button daba diya gaya hai." else "Submit button nahi mila."
        )
    }

    private fun readScreenContent(): ActionResult {
        val service = PhoneAgentAccessibilityService.instance
        if (service == null) {
            return ActionResult(
                actionName = "Read Screen",
                isSuccess = false,
                message = "Accessibility service chalu nahi hai",
                spokenFeedback = "Screen padhne ke liye Accessibility service enable karein."
            )
        }

        val text = service.readScreenContent()
        return ActionResult(
            actionName = "Read Screen",
            isSuccess = true,
            message = text,
            spokenFeedback = "Screen par likha hai: $text"
        )
    }
}
