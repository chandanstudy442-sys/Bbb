package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [CommandLog::class, Macro::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun commandLogDao(): CommandLogDao
    abstract fun macroDao(): MacroDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "phone_agent_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDefaultMacros(database.macroDao())
                    }
                }
            }

            suspend fun populateDefaultMacros(macroDao: MacroDao) {
                val defaultMacros = listOf(
                    Macro(
                        title = "Home Screen",
                        hindiTitle = "होम स्क्रीन पर जाओ",
                        voiceTrigger = "Home screen par jao",
                        actionType = "GLOBAL_HOME",
                        payload = null,
                        iconName = "Home"
                    ),
                    Macro(
                        title = "Flashlight On/Off",
                        hindiTitle = "टॉर्च चालू / बंद करो",
                        voiceTrigger = "Torch on karo",
                        actionType = "TOGGLE_FLASHLIGHT",
                        payload = "toggle",
                        iconName = "FlashlightOn"
                    ),
                    Macro(
                        title = "Open WhatsApp",
                        hindiTitle = "व्हाट्सएप खोलो",
                        voiceTrigger = "WhatsApp open karo",
                        actionType = "OPEN_APP",
                        payload = "com.whatsapp",
                        iconName = "Chat"
                    ),
                    Macro(
                        title = "Open YouTube",
                        hindiTitle = "यूट्यूब खोलो",
                        voiceTrigger = "YouTube kholo",
                        actionType = "OPEN_APP",
                        payload = "com.google.android.youtube",
                        iconName = "PlayArrow"
                    ),
                    Macro(
                        title = "Recent Apps",
                        hindiTitle = "रीसेंट एप्स दिखाओ",
                        voiceTrigger = "Recent apps dikhao",
                        actionType = "SHOW_RECENTS",
                        payload = null,
                        iconName = "Apps"
                    ),
                    Macro(
                        title = "Back Button",
                        hindiTitle = "पीछे जाओ",
                        voiceTrigger = "Peeche jao",
                        actionType = "GLOBAL_BACK",
                        payload = null,
                        iconName = "ArrowBack"
                    ),
                    Macro(
                        title = "Check Battery",
                        hindiTitle = "बैटरी कितनी है",
                        voiceTrigger = "Battery kitna hai",
                        actionType = "CHECK_BATTERY",
                        payload = null,
                        iconName = "BatteryChargingFull"
                    ),
                    Macro(
                        title = "Open Camera",
                        hindiTitle = "कैमरा खोलो",
                        voiceTrigger = "Camera kholo",
                        actionType = "OPEN_APP",
                        payload = "camera",
                        iconName = "CameraAlt"
                    ),
                    Macro(
                        title = "Scroll Screen",
                        hindiTitle = "नीचे स्क्रॉल करो",
                        voiceTrigger = "Neeche scroll karo",
                        actionType = "SCROLL_DOWN",
                        payload = null,
                        iconName = "ArrowDownward"
                    ),
                    Macro(
                        title = "Auto Fill Form",
                        hindiTitle = "फॉर्म भर दो",
                        voiceTrigger = "Form bhar do",
                        actionType = "FILL_FORM",
                        payload = "Auto",
                        iconName = "Description"
                    ),
                    Macro(
                        title = "Open Website",
                        hindiTitle = "वेबसाइट निकालो",
                        voiceTrigger = "Website kholo",
                        actionType = "OPEN_WEBSITE",
                        payload = "https://www.google.com",
                        iconName = "Language"
                    ),
                    Macro(
                        title = "Read Screen",
                        hindiTitle = "स्क्रीन पढ़ो",
                        voiceTrigger = "Screen padho",
                        actionType = "READ_SCREEN",
                        payload = null,
                        iconName = "Description"
                    )
                )
                macroDao.insertAll(defaultMacros)
            }
        }
    }
}
