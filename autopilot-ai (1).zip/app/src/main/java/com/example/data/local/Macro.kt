package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "macros")
data class Macro(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val hindiTitle: String,
    val voiceTrigger: String,
    val actionType: String,
    val payload: String? = null,
    val iconName: String
)
