package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "command_logs")
data class CommandLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val prompt: String,
    val actionType: String,
    val target: String? = null,
    val isSuccess: Boolean = true,
    val responseText: String
)
