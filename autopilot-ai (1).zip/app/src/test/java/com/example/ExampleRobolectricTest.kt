package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.domain.AIAgentEngine
import com.example.domain.DeviceAction
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Phone Agent", appName)
    }

    @Test
    fun `test local intent parser for flashlight and whatsapp`() = runBlocking {
        val engine = AIAgentEngine()

        val torchAction = engine.interpretCommand("torch on karo")
        assertTrue(torchAction is DeviceAction.ToggleFlashlight)
        assertEquals(true, (torchAction as DeviceAction.ToggleFlashlight).turnOn)

        val waAction = engine.interpretCommand("whatsapp open karo")
        assertTrue(waAction is DeviceAction.OpenApp)
        assertEquals("WhatsApp", (waAction as DeviceAction.OpenApp).appName)

        val homeAction = engine.interpretCommand("home screen par jao")
        assertTrue(homeAction is DeviceAction.NavigateHome)

        val batteryAction = engine.interpretCommand("battery kitna hai")
        assertTrue(batteryAction is DeviceAction.CheckBattery)
    }
}
